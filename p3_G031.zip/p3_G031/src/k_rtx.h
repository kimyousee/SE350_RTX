/** 
 * @file:   k_rtx.h
 * @brief:  kernel deinitiation and data structure header file
 * @auther: Yiqing Huang
 * @date:   2014/01/17
 */
 
#ifndef K_RTX_H_
#define K_RTX_H_

/*----- Definitations -----*/
#define K_MSG_ENV
#include "common.h"
#undef K_MSG_ENV

#endif // ! K_RTX_H_
