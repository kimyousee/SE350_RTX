
#ifndef SYSTEM_PROC_H_
#define SYSTEM_PROC_H_

void set_system_procs(void);
void KCD_proc(void);
void CRT_proc(void);

#endif /* SYSTEM_PROC_H_ */
